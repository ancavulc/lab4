package com.example.myapplication;

import android.widget.ImageView;
import android.widget.TextView;

public class TagCar {
    public TextView name;
    public ImageView image;
}