package com.example.myapplication;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends Activity {

    private ListView listaMasini;
    CarAdapter carAdapter;
    private EditText addCar;
    private Button addButton;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaMasini = findViewById(R.id.lv_list_cars);
        carAdapter = new CarAdapter(MainActivity.this);
        listaMasini.setAdapter(carAdapter);
        carAdapter.addCar("Audi", R.drawable.lab5_car_icon);
        carAdapter.addCar("BMW", R.drawable.lab5_car_icon);
        carAdapter.addCar("Dacia", R.drawable.lab5_car_icon);
        carAdapter.addCar("Skoda", R.drawable.lab5_car_icon);
        addCar = findViewById(R.id.add_new_car);
        addCar = findViewById(R.id.b_add_car);

        addButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String nume = addCar.getText().toString();
                int imagine = R.drawable.lab5_car_icon;

                carAdapter.addCar(nume, imagine);
                addCar.setText("");
            }
        });
    }
class Car {
    String name;
    int imageResource;
}

class TagCar {
    TextView name;
    ImageView image;
}
}